<?php

$title = 'Tanggapan';

require '../../public/app.php';

require '../layouts/header.php';

require '../layouts/navPetugas.php';

// logic backend

$id = $_GET["id_pengaduan"];

$result = mysqli_query($conn, "SELECT * FROM pengaduan WHERE id_pengaduan = $id");


if (isset($_POST["submit"])) {

	if (tanggapan($_POST) > 0) {
		$sukses = true;
	} else {
		$error = true;
	}
}

?>

<div class="d-flex justify-content-center mt-2">
    <div class="card w-100 shadow">
        <div class="card-body">
            <?php if (isset($sukses)) : ?>
                <div class="alert alert-dismissible fade show" data-aos="zoom-in" style="background-color: #3bb849;" role="alert">
                    <h6 class="text-gray-100 mt-2">Berhasil menanggapi, Terima kasih sudah menanggapi aduan pelanggan </h6>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true" class="text-light">&times;</span>
                    </button>
                </div>
            <?php endif; ?>

            <?php if (isset($error)) : ?>
                <div class="alert alert-dismissible fade show" data-aos="zoom-in" style="background-color: #b52d2d;" role="alert">
                    <h6 class="text-light mt-2"><?= $error_message; ?></h6>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true" class="text-light">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-6">
                    <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                        <form action="" method="POST">
                            <div class="form-row mb-2">
                                <input type="hidden" name="id_pengaduan" value="<?= $row['id_pengaduan']; ?>">
                                <div class="col">
                                    <label for="exampleInputEmail1">Nama Pelanggan </label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" name="nama" value="<?= $row['nama']; ?>" required>
                                </div>
                                <div class="col">
                                    <label for="exampleInputEmail2">Tanggal Tanggapan</label>
                                    <input type="date" class="form-control" id="exampleInputEmail2" name="tgl_tanggapan" required>
                                </div>
                                <div class="col">
                                    <label for="exampleInputEmail2">Alamat Pelanggan</label>
                                    <input type="text" class="form-control" id="exampleInputEmail2" name="alamat" value="<?= $row['alamat']; ?>" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Isi laporan</label>
                                <input type="text" class="form-control" id="exampleInputPassword1" name="isi_laporan" value="<?= $row['isi_laporan']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword2">Tanggapan</label>
                                <textarea type="text" class="form-control" id="exampleInputPassword2" name="isi_tanggapan" required></textarea>
                            </div>
                            <div class="form-group">
                                <select name="nama_petugas" id="nama_petugas" class="form-control" required>
                                    <option disabled selected>Nama Petugas</option>
                                    <option value="Sin Korompot">Sin Korompot</option>
                                    <option value="Iwan">Iwan</option>
                                </select>
                            </div>
                            <button type="submit" name="submit" class="btn btn-primary">OK!</button>
                        </form>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require '../layouts/footer.php'; ?>
