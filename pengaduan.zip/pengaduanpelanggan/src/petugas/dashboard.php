<?php
$title = 'Dashboard';

require '../../public/app.php';
require '../layouts/header.php';
require '../layouts/navPetugas.php';

// Query untuk mengambil jumlah total pengaduan
$query_pengaduan = "SELECT COUNT(*) as total_pengaduan FROM pengaduan";
$result_pengaduan = mysqli_query($conn, $query_pengaduan);
$row_pengaduan = mysqli_fetch_assoc($result_pengaduan);
$total_pengaduan = $row_pengaduan['total_pengaduan'];

// Query untuk mengambil jumlah total akun pelanggan
$query_akun_pelanggan = "SELECT COUNT(*) as total_akun_pelanggan FROM pelanggan";
$result_akun_pelanggan = mysqli_query($conn, $query_akun_pelanggan);
$row_akun_pelanggan = mysqli_fetch_assoc($result_akun_pelanggan);
$total_akun_pelanggan = $row_akun_pelanggan['total_akun_pelanggan'];

// Query untuk mengambil jumlah total tanggapan
$query_tanggapan = "SELECT COUNT(*) as total_tanggapan FROM tanggapan";
$result_tanggapan = mysqli_query($conn, $query_tanggapan);
$row_tanggapan = mysqli_fetch_assoc($result_tanggapan);
$total_tanggapan = $row_tanggapan['total_tanggapan'];
?>

<div class="d-flex justify-content-center text-center py-5" data-aos="zoom-in">
  <div class="content col-8">
    <i class="fas fa-atlas fa-5x mb-2"></i>
    <h1 class="mb-3">Welcome back to the <span class="text-primary">Pengaduan</span> web <br>
      <span class="text-primary">happy work </span>and activities.
    </h1>
    <p>Jumlah Pengaduan: <?= $total_pengaduan; ?></p>
    <p>Jumlah Akun Pelanggan: <?= $total_akun_pelanggan; ?></p>
    <p>Jumlah Tanggapan: <?= $total_tanggapan; ?></p>
    <a href="laporan.php" class="btn btn-primary btn-icon-split">
      <span class="icon text-white-50">
        <i class="fas fa-book-open"></i>
      </span>
      <span class="text">Lihat Laporan</span>
    </a>
  </div>
</div>

<?php require '../layouts/footer.php'; ?>
