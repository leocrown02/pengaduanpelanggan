<?php

$title = 'Tanggapan';

require '../../public/app.php';
require '../layouts/header.php';
require '../layouts/navAdmin.php';

// Logic backend
$query = "SELECT * FROM ( ( tanggapan 
           INNER JOIN pengaduan ON tanggapan.id_pengaduan = pengaduan.id_pengaduan )
           INNER JOIN petugas ON tanggapan.id_petugas = petugas.id_petugas ) 
           ORDER BY id_tanggapan DESC";

$result = mysqli_query($conn, $query);

// Periksa apakah query berhasil
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

?>

<style>
.hidden-colomn {
    display: none;
}
</style>

<table class="table table-bordered shadow text-center" data-aos="fade-up" data-aos-duration="900">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Id Tanggapan</th>
      <th scope="col">Id Pengaduan</th>
      <th scope="col" class="hidden-colomn">Id Petugas</th>
      <th scope="col">Nama</th>
      <th scope="col">Tanggal Tanggapan</th>
      <th scope="col">Alamat</th>
      <th scope="col">Isi Tanggapan</th>
      <th scope="col">Nama Petugas</th>
      <th scope="col">Status</th>
    </tr>
  </thead>
  <tbody>
    <?php 
    $i = 1; 
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) : ?>
          <tr>
            <th scope="row"><?= $i; ?>.</th>
            <td><?= $row["id_tanggapan"]; ?></td>
            <td><?= $row["id_pengaduan"]; ?></td>
            <td class="hidden-colomn"><?= $row["id_petugas"]; ?></td>
            <td><?= $row["nama"]; ?></td>
            <td><?= $row["tgl_tanggapan"]; ?></td>
            <td><?= $row["alamat"]; ?></td>
            <td><?= $row["isi_tanggapan"]; ?></td>
            <td><?= $row["nama_petugas"]; ?></td>
            <td><?= $row["status"]; ?></td>
          </tr>
          <?php 
          $i++; 
        endwhile;
    } else {
        echo "<tr><td colspan='9'>No data found</td></tr>";
    }
    ?>
  </tbody>
</table>

<?php require '../layouts/footer.php'; ?>
