<?php

$title = 'Buat Laporan';

require '../../public/app.php';
require '../layouts/header.php';
require '../layouts/navUser.php';

// Logic
if (isset($_POST["submit"])) {
  if (tambahAduan($_POST) > 0) {
    $sukses = true;
  } else {
    $error = true;
  }
}

?>

<h3 class="text-gray-900" data-aos="fade-left">Buat laporan keluh kesah anda disini</h3>
<hr>
<div class="card border-bottom-primary shadow" data-aos="fade-up">
  <div class="card-body">
    <div class="container">
      <?php if (isset($sukses)) : ?>
        <div class="alert alert-dismissible fade show" style="background-color: #3bb849;" role="alert">
          <h5 class="text-gray-100 mt-2">Aduan atau laporan sedang di proses, Terima kasih!.</h5>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true" class="text-light">&times;</span>
          </button>
        </div>
      <?php endif; ?>

      <?php if (isset($error)) : ?>
        <div class="alert alert-dismissible fade show" style="background-color: #b52d2d;" role="alert">
          <h6 class="text-light mt-2">Maaf aduan atau laporan anda gagal di proses</h6>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true" class="text-light">&times;</span>
          </button>
        </div>
      <?php endif; ?>

      <div class="row">
        <div class="col-12 mt-2"> <!-- Mengubah col-8 menjadi col-12 untuk mengisi lebar penuh -->
          <form action="" method="POST">
            <div class="form-row mb-3">
              <div class="col">
                <label for="tgl_pengaduan" class="text-lg">Tanggal</label>
                <input type="date" class="form-control mb-2" id="Tanggal Pengaduan" name="tgl_pengaduan">
                
                <label for="nama" class="text-lg">Nama Pelanggan</label>
                <input type="text" class="form-control mb-2" id="Nama" name="nama">

                <label for="alamat" class="text-lg">Alamat</label>
                <input type="text" class="form-control mb-2" id="Alamat" name="alamat">
                
                <label for="foto" class="text-lg">Foto</label>
                <input type="file" class="form-control-file" id="Foto" name="foto">
              </div>
              <div class="col">
                <label for="isi_laporan">Isi laporan</label>
                <textarea class="form-control" id="Isi Laporan" rows="5" name="isi_laporan"></textarea>
                <label for="kategori" class="text-lg">Kategori Pengaduan</label>
                <select class="form-control mb-2" id="Kategori engaduan" name="kategori_pengaduan">
                  <option value="kategori1">Kategori 1</option>
                  <option value="kategori2">Kategori 2</option>
                  <option value="kategori3">Kategori 3</option>
                  <option value="kategori4">Kategori 4</option>
                </select>
                
                <div class="form-check">
                  <input type="hidden" name="status" value="proses">
                </div>
                
                <div class="d-flex justify-content-end mt-4">
                  <button class="btn btn-outline-primary" name="submit">Submit</button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require '../layouts/footer.php'; ?>
