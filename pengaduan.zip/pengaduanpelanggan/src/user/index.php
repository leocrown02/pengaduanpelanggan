<?php

$title = 'Pengaduan Pelanggan';

require '../../public/app.php';

require '../layouts/header.php';

// logic backend

// mengambil angka pengaduan dari database
$pengaduan = mysqli_query($conn, "SELECT * FROM pengaduan ORDER BY id_pengaduan DESC LIMIT 1");

// mengambil angka tanggapan dari database
$tanggapan = mysqli_query($conn, "SELECT * FROM tanggapan ORDER BY id_tanggapan DESC LIMIT 1");

// mengambil jumlah total akun pelanggan dari database
$jumlah_akun_pelanggan = mysqli_query($conn, "SELECT COUNT(*) as total_akun_pelanggan FROM pelanggan");

// Eksekusi query untuk menghitung jumlah total pengaduan
$query_pengaduan = "SELECT COUNT(*) as total_pengaduan FROM pengaduan";
$result_pengaduan = mysqli_query($conn, $query_pengaduan);
$row_pengaduan = mysqli_fetch_assoc($result_pengaduan);
$total_pengaduan = $row_pengaduan['total_pengaduan'];

// Eksekusi query untuk menghitung jumlah total tanggapan
$query_tanggapan = "SELECT COUNT(*) as total_tanggapan FROM tanggapan";
$result_tanggapan = mysqli_query($conn, $query_tanggapan);
$row_tanggapan = mysqli_fetch_assoc($result_tanggapan);
$total_tanggapan = $row_tanggapan['total_tanggapan'];

// Eksekusi query untuk mengambil jumlah total akun pelanggan
$result_akun_pelanggan = mysqli_fetch_assoc($jumlah_akun_pelanggan);
$total_akun_pelanggan = $result_akun_pelanggan['total_akun_pelanggan'];

?>

<nav class="navbar navbar-expand-lg navbar-dark bg-warning py-3 shadow">
  <div class="container" data-aos="fade-down">
    <a class="navbar-brand" href="#">
      <i class="fas fa-atlas"></i> Pengaduan Pelanggan
    </a>
    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
      <ul class="navbar-nav">
        <a href="login.php" class="btn btn-light mr-3">Login</a>
        <a href="register.php" class="btn btn-outline-light">Registrasi</a>
      </ul>
    </div>
  </div>
</nav>

<div class="bg-gradient-warning" style="border-bottom-right-radius: 100px; border-bottom-left-radius: 100px; padding:150px;">
  <div class="container d-flex justify-content-center" data-aos="zoom-in">
    <div class="text-center col-8 text-light" style="margin-top: -25px;">
      <h1>Pengaduan Pelanggan</h1>
      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Laudantium alias debitis,
        officiis accusamus omnis unde eligendi repudiandae illo delectus,
        dolore aliquam doloremque libero reiciendis iste excepturi exercitationem, provident necessitatibus error.</p>
      <a href="login.php" class="btn btn-outline-light">Buat laporan sekarang!</a>
    </div>
  </div>
</div>

<div class="container" style="margin-top: -35px;">
  <div class="row mb-3">
    <!-- Menampilkan jumlah total pengaduan -->
    <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-duration="500">
      <div class="card border-left-info border-bottom-info shadow-lg h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col ml-3">
              <div class="h5 mb-0 font-weight-bold text-info"><?= $total_pengaduan; ?> Pengaduan</div>
            </div>
            <i class="fas fa-comment fa-2x text-gray-500"></i>
          </div>
        </div>
      </div>
    </div>

    <!-- Menampilkan jumlah total akun pelanggan -->
    <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-duration="500">
      <div class="card border-left-warning border-bottom-warning shadow-lg h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col ml-3">
              <div class="h5 mb-0 font-weight-bold text-warning"><?= $total_akun_pelanggan; ?> Akun pelanggan</div>
            </div>
            <i class="fas fa-users fa-2x text-gray-500"></i>
          </div>
        </div>
      </div>
    </div>

    <!-- Menampilkan jumlah total tanggapan -->
    <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-duration="500">
      <div class="card border-left-success border-bottom-success shadow-lg h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col ml-3">
              <div class="h5 mb-0 font-weight-bold text-success"><?= $total_tanggapan; ?> Tanggapan</div>
            </div>
            <i class="fas fa-comments fa-2x text-gray-500"></i>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="container">
  <div class="row justify-content-center">
    <div class="col-6" data-aos="fade-right">
      <div class="desc text-center" style="margin-top: 130px;">
        <h4 class="text-justify text-gray-900">Buat laporan, aduan dan keluh kesah anda di website aduan pelanggan ini dan jangan meyebarkan berita hoax!</h4>
      </div>
    </div>
  </div>
</div>

<!-- info -->
<div class="bg-gradient-warning py-5">
  <div class="container text-center text-light">
    <h1 class="mb-3">Info Aduan Pelanggan</h1>
    <a href="mailto:dhillamoko02@gmail.com" class="btn btn-light mr-1">Chat admin</a>
    <a href="mailto:dhillamoko02@gmail.com" class="btn btn-outline-light ml-1">Contact Developer</a>
  </div>
</div>

<?php require '../layouts/footer.php'; ?>
