<?php

$title = 'Login';

require '../../public/app.php';
require '../layouts/header.php';

// logic backend
if (isset($_POST['submit'])) {
  $username = $_POST['username'];
  $password = $_POST['password'];
  $result = mysqli_query($conn, "SELECT * FROM pelanggan WHERE username = '$username'");

  if (mysqli_num_rows($result) === 1) {
    header("Location: dashboard.php");
  } else {
    $error = true;
  }
}
?>

<div class="d-flex justify-content-center align-items-center min-vh-100">
  <div class="card shadow-lg border-0" style="width: 400px;" data-aos="fade-down">
    <div class="card-body">
      <?php if (isset($error)) : ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <h6 class="text-white mt-2">Maaf username atau password anda salah</h6>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true" class="text-light">&times;</span>
          </button>
        </div>
      <?php endif; ?>

      <h3 class="text-center text-primary font-weight-bold">Login</h3>
      <hr class="bg-gradient-primary">

      <form action="" method="post">
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" class="form-control shadow-sm" id="username" placeholder="Masukkan username" name="username" required>
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" class="form-control shadow-sm" id="password" placeholder="Masukkan password" name="password" required>
        </div>
        <button type="submit" name="submit" class="btn btn-primary btn-block shadow-lg">Masuk</button>
        <a href="../petugas/login.php" class="btn btn-outline-primary btn-block shadow-lg mt-2">Masuk sebagai petugas</a>
        <div class="text-center mt-3">
          <a href="register.php" class="text-gray-600" style="text-decoration: none;">Belum Punya Akun?</a>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require '../layouts/footer.php'; ?>
