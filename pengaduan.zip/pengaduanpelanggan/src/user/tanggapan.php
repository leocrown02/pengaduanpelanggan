<?php

$title = 'Tanggapan';

require '../../public/app.php';

require '../layouts/header.php';

require '../layouts/navUser.php';


// logic backend

$query = "SELECT * FROM ( ( tanggapan INNER JOIN pengaduan ON tanggapan.id_pengaduan = pengaduan.id_pengaduan )
          INNER JOIN petugas ON tanggapan.id_petugas = petugas.id_petugas ) ORDER BY id_tanggapan DESC";

$result = mysqli_query($conn, $query);

?>


<table class="table table-bordered shadow text-center" data-aos="fade-up" data-aos-duration="900">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Id Tanggapan</th>
      <th scope="col">Id Pengaduan</th>
      <th scope="col">Id Petugas</th>
      <th scope="col">Tanggal Tanggapan</th>
      <th scope="col">Isi Tanggapan</th>
      <th scope="col">Status</th>
    </tr>
  </thead>
  <tbody>
    <?php $i = 1; ?>
    <?php while ($row = mysqli_fetch_assoc($result)) : ?>
      <tr>
        <th scope="row"><?= $i; ?>.</th>
        <td><?= $row["id_tanggapan"]; ?></td>
        <td><?= $row["id_pengaduan"]; ?></td>
        <td><?= $row["id_petugas"]; ?></td>
        <td><?= $row["tgl_tanggapan"]; ?></td>
        <td><?= $row["isi_tanggapan"]; ?></td>
        <td><?= $row["status"]; ?></td>
      </tr>
      <?php $i++; ?>
    <?php endwhile; ?>
  </tbody>
</table>


<?php require '../layouts/footer.php'; ?>