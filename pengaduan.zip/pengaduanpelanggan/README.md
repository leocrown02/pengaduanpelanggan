# Hello Everyone
I Creating a website about public complaints created using the following template sb admin 2 and Bootstrap for the frontend and native PHP for the backend

<br>
<h3>website display</h3>

<br>

- Landing pages

<img src="assets/img/landing.jpg" alt="">

<br>

- Login

<img src="assets/img/login.jpg">

<br>

- Dashboard

<img src="assets/img/dashboard.jpg">

