<?php

$conn = mysqli_connect("localhost", "root", "", "informasi");

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

function tambahAduan($data)
{
    global $conn;

    $tgl = htmlspecialchars($data["tgl_pengaduan"]);
    $nama = htmlspecialchars($data["nama"]);
    $alamat = htmlspecialchars($data["alamat"]);
    $isi = htmlspecialchars($data["isi_laporan"]);
    $foto = htmlspecialchars($data["foto"]);
    $status = htmlspecialchars($data["status"]);
    $kategori = htmlspecialchars($data["kategori_pengaduan"]);

    $query = "INSERT INTO pengaduan (tgl_pengaduan, nama, alamat, isi_laporan, foto, status, kategori_pengaduan) VALUES ('$tgl', '$nama', '$alamat', '$isi', '$foto', '$status', '$kategori')";

    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}



function verify($data)
{

    global $conn;

    $id = htmlspecialchars($data["id_pengaduan"]);
    $nama = htmlspecialchars($data["nama"]);
    $alamat = htmlspecialchars($data["alamat"]);
    $tgl = htmlspecialchars($data["tgl_pengaduan"]);
    $isi = htmlspecialchars($data["isi_laporan"]);
  #  $foto = htmlspecialchars($data["foto"]);
    $status = htmlspecialchars($data["status"]);

    $query = "UPDATE pengaduan SET
                id_pengaduan = '$id',
                nama = '$nama',
                alamat = '$alamat',
                tgl_pengaduan = '$tgl',
                isi_laporan = '$isi',
                status = '$status'
                WHERE id_pengaduan = '$id' ";

    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}

function tanggapan($data)
{
    global $conn;

    $id_pengaduan = htmlspecialchars($data["id_pengaduan"]);
    $nama = htmlspecialchars($data["nama"]);
    $tgl_tanggapan = htmlspecialchars($data["tgl_tanggapan"]);
    $alamat = htmlspecialchars($data["alamat"]);
    $isi_laporan = htmlspecialchars($data["isi_laporan"]);
    $isi_tanggapan = htmlspecialchars($data["isi_tanggapan"]);
    $nama_petugas = htmlspecialchars($data["nama_petugas"]);

    // Insert tanggapan into tanggapan table
    $query_tanggapan = "INSERT INTO tanggapan (id_pengaduan, nama, tgl_tanggapan, alamat, isi_laporan, isi_tanggapan, nama_petugas) 
                        VALUES ('$id_pengaduan', '$nama', '$tgl_tanggapan', '$alamat', '$isi_laporan', '$isi_tanggapan', '$nama_petugas')";

    mysqli_query($conn, $query_tanggapan);

    // Update status pengaduan to 'selesai'
    $query_update_pengaduan = "UPDATE pengaduan SET status = 'selesai' WHERE id_pengaduan = '$id_pengaduan'";
    mysqli_query($conn, $query_update_pengaduan);

    return mysqli_affected_rows($conn);
}



function regisUser($data)
{

    global $conn;

    $id_pelanggan = htmlspecialchars($data["id_pelanggan"]);
    $nama = htmlspecialchars($data["nama"]);
    $username = htmlspecialchars($data["username"]);
    $password = htmlspecialchars($data["password"]);
    $telepon = htmlspecialchars($data["telepon"]);
    $email = htmlspecialchars($data["email"]);

    mysqli_query($conn, "INSERT INTO pelanggan VALUES ('$id_pelanggan', '$nama', '$username', '$password', '$telepon', '$email')");

    return mysqli_affected_rows($conn);
}

  
function addPetugas($data)
{

    global $conn;

   # $id_petugas = htmlspecialchars($data["id_petugas"]);
    $nama = htmlspecialchars($data["nama_petugas"]);
    $username = htmlspecialchars($data["username"]);
    $password = htmlspecialchars($data["password"]);
    $telepon = htmlspecialchars($data["telepon"]);
    $level = htmlspecialchars($data["level"]);

    mysqli_query($conn, "INSERT INTO petugas VALUES ('', '$nama', '$username', '$password', '$telepon', '$level')");

    return mysqli_affected_rows($conn);
}

function editPetugas($data)
{

    global $conn;

    $id_petugas = htmlspecialchars($data["id_petugas"]);
    $nama = htmlspecialchars($data["nama_petugas"]);
    $username = htmlspecialchars($data["username"]);
    $password = htmlspecialchars($data["password"]);
    $telepon = htmlspecialchars($data["telepon"]);
    $level = htmlspecialchars($data["level"]);

    $query = "UPDATE petugas SET
                nama_petugas = '$nama',
                username = '$username',
                password = '$password',
                telepon = '$telepon',
                level = '$level'
                WHERE id_petugas = '$id_petugas'
                ";

    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}


function deletePetugas($id)
{

    global $conn;

    mysqli_query($conn, "DELETE FROM petugas WHERE id_petugas = $id");

    return mysqli_affected_rows($conn);
}